"""
Created on Nov 18, 2026

@author: keith.chambers

EDS Connection screen.

Manages the EDS connection profile and provides
connection testing.
"""

import logging
from pathlib import Path

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivy.properties import BooleanProperty, StringProperty, ListProperty

from common.configuration import ConfigError, ConfigValidationError
from datetime import datetime
from threading import Thread

from kivy.clock import Clock

from EvalEDSApp.config import APP_NAMESPACE
from EvalEDSApp.eds import EDSConnectionProfile


logger = logging.getLogger(APP_NAMESPACE)


class EDSConnectionScreen(Screen):
    """Manage the EDS connection profile."""

    has_changes = BooleanProperty(False)
    change_status = StringProperty("All changes saved")

    connection_status = StringProperty("Not tested")

    _saved_values = None
    
    screen_message = StringProperty()
    screen_message_color = ListProperty([0.15, 0.5, 0.2, 1])    

    # --------------------------------------------------------
    # Read form values
    # --------------------------------------------------------
    def _read_form_values(self) -> tuple:
        return (
            self.ids.url.text.strip(),
            self.ids.port.text.strip(),
            self.ids.timeout.text.strip(),
            self.ids.retry_interval.text.strip(),
        )

    # --------------------------------------------------------
    # Change tracking
    # --------------------------------------------------------
    def update_change_state(self, *args) -> None:

        if self._saved_values is None:
            return

        self.has_changes = (
            self._read_form_values() != self._saved_values
        )

        self.change_status = (
            "Unsaved changes"
            if self.has_changes
            else "All changes saved"
        )

        # Clear previous feedback when the profile is modified.
        if self.has_changes:
            self.screen_message = ""

    def _set_saved_baseline(self) -> None:

        self._saved_values = self._read_form_values()
        self.has_changes = False
        self.change_status = "All changes saved"

    # --------------------------------------------------------
    # Load active profile
    # --------------------------------------------------------

    def load_from_profile(self) -> None:
        """Populate the screen from the active profile."""

        app = App.get_running_app()

        if app is None or not hasattr(app, "eds_connection_profile"):
            return

        profile = app.eds_connection_profile

        self.ids.connection_file.text = str(
            app.eds_connection_manager.config_file
        )

        self.ids.url.text = profile.url
        self.ids.port.text = str(profile.port)
        self.ids.timeout.text = str(profile.timeout)
        self.ids.retry_interval.text = str(profile.retry_interval)

        self.connection_status = "Not tested"

        self._set_saved_baseline()

    # --------------------------------------------------------
    # Load saved profile
    # --------------------------------------------------------

    def on_load_profile(self) -> None:

        app = App.get_running_app()

        try:
            profile = app.eds_connection_manager.load()

        except ConfigError as exc:
            logger.exception("Unable to load EDS connection profile")
            self._report_status(
                f"Unable to load EDS profile: {exc}",
                "ERROR"
            )
            return

        app.eds_connection_profile = profile
        app.eds_connection_service.set_active_profile(profile)

        self.load_from_profile()
        self.screen_message = ""
        self.connection_status = "Not tested"

        self._report_status(
            "EDS connection profile loaded successfully."
        )

    # --------------------------------------------------------
    # Build candidate profile
        # --------------------------------------------------------
    def _build_profile(self) -> EDSConnectionProfile:
        """Build a candidate profile from the displayed values."""
    
        try:
            port = int(self.ids.port.text.strip())
            timeout = int(self.ids.timeout.text.strip())
            retry_interval = int(
                self.ids.retry_interval.text.strip()
            )
    
        except ValueError as exc:
            raise ValueError(
                "Port, timeout and retry interval must contain integers."
            ) from exc
    
        return EDSConnectionProfile(
            url=self.ids.url.text.strip(),
            port=port,
            timeout=timeout,
            retry_interval=retry_interval,
        )
    
    # --------------------------------------------------------
    # Set message to screen
    # --------------------------------------------------------
    def _set_screen_message(

        self,
        message: str,
        level: str = "INFO"
    ) -> None:
        """Display a message directly on the EDS Connection screen."""
    
        colors = {
            "INFO": [0.15, 0.35, 0.65, 1],
            "SUCCESS": [0.15, 0.5, 0.2, 1],
            "WARNING": [0.75, 0.45, 0.05, 1],
            "ERROR": [0.75, 0.15, 0.15, 1],
        }
    
        self.screen_message = message
        self.screen_message_color = colors.get(
            level,
            colors["INFO"]
        )
        
    # --------------------------------------------------------
    # Verify profile
    # --------------------------------------------------------
    def on_verify_profile(self) -> None:

        app = App.get_running_app()

        try:
            candidate = self._build_profile()
            app.eds_connection_manager.validate(candidate)

        except (ValueError, ConfigError) as exc:
            
            message= f"EDS Profile verification failed: {exc}"
            
            logger.warning(message)
            self._set_screen_message(message, "ERROR")
            self._report_status(message, "ERROR")
            return

        self._set_screen_message("EDS connection profile is valid.","SUCCESS")        
        self._report_status("EDS connection profile is valid.")

    # --------------------------------------------------------
    # Test connection
    # --------------------------------------------------------
    # --------------------------------------------------------
    # Test connection
    # --------------------------------------------------------

    def on_test_connection(self) -> None:
        """
        Test the values currently displayed on screen.

        Testing does not save or activate the candidate profile.
        The HTTP request runs in a background thread.
        """

        app = App.get_running_app()

        # Prevent multiple simultaneous tests from this screen.
        if getattr(self, "_test_in_progress", False):
            return

        # Build candidate profile from displayed values.
        try:
            candidate = self._build_profile()

        except ValueError as exc:
            message = f"Invalid connection configuration: {exc}"

            self.connection_status = "Invalid configuration"
            self._set_screen_message(message, "ERROR")
            self._report_status(message, "ERROR")
            return

        # Validate before attempting HTTP communication.
        try:
            app.eds_connection_manager.validate(candidate)

        except ConfigValidationError as exc:
            message = f"Invalid connection configuration: {exc}"

            self.connection_status = "Invalid configuration"
            self._set_screen_message(message, "ERROR")
            self._report_status(message, "ERROR")
            return

        # Record the endpoint and attempt time.
        endpoint = app.get_eds_endpoint(candidate)

        attempted_at = datetime.now().astimezone().strftime(
            "%Y-%m-%d %H:%M:%S %Z"
        )

        self._test_in_progress = True
        self.connection_status = "Connecting"

        self._set_screen_message(
            "Testing EDS connection...",
            "INFO"
        )

        # Update shared Status screen.
        app.update_connection_summary(
            state="Connecting",
            endpoint=endpoint,
            last_attempt=attempted_at,
            message="Testing EDS connection..."
        )

        self._report_status(
            f"Testing EDS connection at {endpoint}..."
        )

        # Start background test.
        self._connection_test_thread = Thread(
            target=self._connection_test_worker,
            args=(app, candidate, endpoint, attempted_at),
            daemon=True,
            name="EDS-ManualTest"
        )

        self._connection_test_thread.start()
        
    # --------------------------------------------------------
    # Manual connection test worker
    # --------------------------------------------------------

    def _connection_test_worker(
        self,
        app,
        candidate,
        endpoint: str,
        attempted_at: str
    ):
        """Perform the HTTP connection test in the background."""

        try:
            result = app.eds_connection_service.test_connection(
                candidate
            )

        except Exception as exc:
            logger.exception(
                "Unexpected error during manual EDS connection test"
            )

            message = str(exc)

            Clock.schedule_once(
                lambda dt, msg=message:
                    self._complete_connection_test(
                        False,
                        msg,
                        endpoint,
                        attempted_at
                    ),
                0
            )
            return

        Clock.schedule_once(
            lambda dt, success=result.success, msg=result.message:
                self._complete_connection_test(
                    success,
                    msg,
                    endpoint,
                    attempted_at
                ),
            0
        )

    # --------------------------------------------------------
    # Complete manual connection test
    # --------------------------------------------------------

    def _complete_connection_test(
        self,
        success: bool,
        message: str,
        endpoint: str,
        attempted_at: str
    ):
        """Update the UI after a manual connection test."""

        self._test_in_progress = False

        app = App.get_running_app()

        if success:
            self.connection_status = "Connected"

            screen_message = "EDS connection test successful."

            self._set_screen_message(
                screen_message,
                "SUCCESS"
            )

            app.update_connection_summary(
                state="Connected",
                endpoint=endpoint,
                last_attempt=attempted_at,
                message=message
            )

            self._report_status(screen_message)

        else:
            self.connection_status = "Connection failed"

            screen_message = (
                f"EDS connection test failed: {message}"
            )

            self._set_screen_message(
                screen_message,
                "ERROR"
            )

            app.update_connection_summary(
                state="Disconnected",
                endpoint=endpoint,
                last_attempt=attempted_at,
                message=message
            )

            self._report_status(
                screen_message,
                "ERROR"
            )
            
    # --------------------------------------------------------
    # Save profile
    # --------------------------------------------------------
    def on_save_profile(self) -> None:
        """Validate and save the displayed connection profile."""
    
        if not self.has_changes:
            self._set_screen_message(
                "No profile changes to save.",
                "INFO"
            )
            return
    
        app = App.get_running_app()
    
        try:
            candidate = self._build_profile()
    
            app.save_eds_connection_profile(candidate)
    
        except (ValueError, ConfigValidationError) as exc:
            message = f"Unable to save EDS profile: {exc}"
    
            logger.warning(message)
    
            self._set_screen_message(message, "ERROR")
            self._report_status(message, "ERROR")
            return
    
        except ConfigError as exc:
            message = f"Unable to save EDS profile: {exc}"
    
            logger.exception(message)
    
            self._set_screen_message(message, "ERROR")
            self._report_status(message, "ERROR")
            return
    
        self.load_from_profile()
    
        message = "EDS connection profile saved successfully."
    
        self._set_screen_message(message, "SUCCESS")
        self._report_status(message)
    # --------------------------------------------------------
    # Status reporting
    # --------------------------------------------------------

    @staticmethod
    def _report_status(message: str, level: str = "INFO") -> None:

        app = App.get_running_app()

        if app is not None and app.root is not None:
            app.root.set_status(message, level)


Builder.load_file(str(Path(__file__).with_suffix(".kv")))
