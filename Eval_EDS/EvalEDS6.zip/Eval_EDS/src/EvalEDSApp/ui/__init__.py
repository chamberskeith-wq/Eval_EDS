
"""EvalEDS user-interface screens."""

from .stream_inspector_screen import StreamInspectorScreen
from .stream_configuration_screen import StreamConfigurationScreen
from .eds_administration_screen import EDSAdministrationScreen
from .logging_screen import LoggingScreen
from .settings_screen import SettingsScreen


__all__ = [
    "StreamInspectorScreen",
    "StreamConfigurationScreen"
    "EDSAdministrationScreen",
    "LoggingScreen",
    "SettingsScreen",
]
